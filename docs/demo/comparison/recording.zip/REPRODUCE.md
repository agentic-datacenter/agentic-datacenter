# Reproduce the worked comparison

This archive holds a development run with the six-POD example facility. Seed 1.
The weather and chiller failure are simulated inputs. The run was made from a
reconstructed checkout, so the simulator Git commit was not available to the
runner. The recorded SHA-256 values identify the other inputs and evidence.

From a checkout of the repository containing this report, run `uv sync --locked`.
Start the sample adapter in one terminal:

    uv run python examples/http-gate/server.py --port 8788

Run the simulation in a second terminal:

    export ADC_GATE_URL=http://127.0.0.1:8788 ADC_GATE_NAME=example_http
    uv run agentic-datacenter demo --facility examples/byodc --scenario OP-03 \
        --seed 1 --gate static_allowlist --gate http_gate --out build/report-comparison

The copies under `inputs/` preserve the facility bundle, contract YAML and
dependency lock file used for this example. View the archived `index.html`
for every proposal. From the extracted directory use the repository's CLI
to verify each `evidence/OP-03.*` directory against its manifest. Use
`demo.json` to reproduce the plots from the recorded sampling timestamps
and values.
