# Reproduce the worked comparison

This archive holds a development run with the six-POD example facility. Seed 1.
The weather and chiller failure are simulated inputs. It was made at commit
`bc73ff36c3634b932a4654958ea9836dc5535450` of the repository; every evidence manifest names it.

From a checkout of that commit, run `uv sync --locked`.
Start the sample adapter in one terminal:

    uv run python examples/http-gate/server.py --port 8788

Run the simulation in a second terminal:

    export ADC_GATE_URL=http://127.0.0.1:8788 ADC_GATE_NAME=example_http
    uv run agentic-datacenter demo --facility examples/byodc --scenario OP-03 \
        --seed 1 --gate static_allowlist --gate http_gate --out build/report-comparison

The copies under `inputs/` preserve the facility bundle and contract YAML used
for this example; the dependency lock is the repository's `uv.lock` at that
commit. View the archived `index.html` for every proposal. From the extracted
directory use the repository's CLI to verify each `evidence/OP-03.*` directory
against its manifest (`agentic-datacenter scenario verify`), and read each
action end to end in its `action_trace.md`. Use `demo.json` to reproduce the
plots from the recorded sampling timestamps and values.
