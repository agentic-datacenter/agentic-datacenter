# What became of each action in OP-03

Times are minutes into the scenario. Each line says who observed it. `receipt`, `signature` and `physical` are kept apart: a missing receipt, a signature that was not checked and a write nobody observed at the plant are three different things.

## prop-00000: `chw.set_supply_setpoint.v1`

Receipt: none. Signature: not_checked. At the plant: no_write. Stopped by: gate.

| Time | Step | What | Observed by |
| ---: | --- | --- | --- |
| 5:00 | proposal | agent-1 proposes it: one large step to the top of the range | control path |
| 5:00 | decision | example_http: DENY | gate |
| 5:00 | outcome | NOT_EXECUTED deny | control path |

## prop-00001: `chw.set_supply_setpoint.v1`

Receipt: none. Signature: not_checked. At the plant: acknowledged.

| Time | Step | What | Observed by |
| ---: | --- | --- | --- |
| 10:00 | proposal | agent-1 proposes it: another small step | control path |
| 10:00 | decision | example_http: ALLOW | gate |
| 10:00 | command | cooling.chw_plant[CHW].chws_sp_c: 18.0 → 18.5, accepted | command service |
| 10:00 | command | cooling.tes[TES-1].supply_sp_c: 18.0 → 18.5, accepted | command service |
| 10:00 | outcome | ROLLED_BACK premise no longer holds: no_active_alarm(priority >= HIGH, system in [CHW, POD]) (active: cooling.chw_plant[CHW].ch1_state) | control path |

## prop-00002: `pod.set_supply_air_setpoint.v1`

Receipt: none. Signature: not_checked. At the plant: no_write. Stopped by: gate.

| Time | Step | What | Observed by |
| ---: | --- | --- | --- |
| 15:00 | proposal | agent-1 proposes it: top of the envelope | control path |
| 15:00 | decision | example_http: DENY | gate |
| 15:00 | outcome | NOT_EXECUTED deny | control path |

## prop-00003: `chw.take_chiller_out_of_service.v1`

Receipt: none. Signature: not_checked. At the plant: no_write. Stopped by: operator.

| Time | Step | What | Observed by |
| ---: | --- | --- | --- |
| 20:00 | proposal | agent-1 proposes it: maintenance, now | control path |
| 20:00 | decision | example_http: VERIFY | gate |
| 25:00 | rejection | operator-ola: no work permit for this | control path |
| 25:00 | outcome | REJECTED rejected by operator-ola: no work permit for this | control path |

## prop-00004: `chw.set_supply_setpoint.v1`

Receipt: none. Signature: not_checked. At the plant: acknowledged.

| Time | Step | What | Observed by |
| ---: | --- | --- | --- |
| 25:00 | proposal | agent-1 proposes it: another small step | control path |
| 25:00 | decision | example_http: ALLOW | gate |
| 25:00 | command | cooling.chw_plant[CHW].chws_sp_c: 18.5 → 19.0, accepted | command service |
| 25:00 | command | cooling.tes[TES-1].supply_sp_c: 18.5 → 19.0, accepted | command service |
| 25:00 | outcome | ROLLED_BACK premise no longer holds: no_active_alarm(priority >= HIGH, system in [CHW, POD]) (active: cooling.chw_plant[CHW].ch1_state) | control path |

## prop-00005: `pumps.set_dp_setpoint.v1`

Receipt: none. Signature: not_checked. At the plant: no_write. Stopped by: gate.

| Time | Step | What | Observed by |
| ---: | --- | --- | --- |
| 30:00 | proposal | agent-1 proposes it: bottom of the range | control path |
| 30:00 | decision | example_http: DENY | gate |
| 30:00 | outcome | NOT_EXECUTED deny | control path |

## prop-00006: `r3.hard_floor.v1`

Receipt: none. Signature: not_checked. At the plant: no_write. Stopped by: gate.

| Time | Step | What | Observed by |
| ---: | --- | --- | --- |
| 35:00 | proposal | agent-1 proposes it: quiet night | control path |
| 35:00 | decision | example_http: DENY | gate |
| 35:00 | outcome | NOT_EXECUTED deny | control path |

## prop-00007: `chw.set_supply_setpoint.v1`

Receipt: none. Signature: not_checked. At the plant: no_write. Stopped by: gate.

| Time | Step | What | Observed by |
| ---: | --- | --- | --- |
| 40:00 | proposal | agent-1 proposes it: outside the range | control path |
| 40:00 | decision | example_http: DENY | gate |
| 40:00 | outcome | NOT_EXECUTED deny | control path |

## prop-00008: `open.every.breaker.v1`

Receipt: none. Signature: not_checked. At the plant: no_write. Stopped by: gate.

| Time | Step | What | Observed by |
| ---: | --- | --- | --- |
| 45:00 | proposal | agent-1 proposes it: a contract that does not exist | control path |
| 45:00 | decision | example_http: DENY | gate |
| 45:00 | outcome | NOT_EXECUTED deny | control path |

## prop-00009: `chw.set_supply_setpoint.v1`

Receipt: none. Signature: not_checked. At the plant: no_write. Stopped by: gate.

| Time | Step | What | Observed by |
| ---: | --- | --- | --- |
| 50:00 | proposal | agent-1 proposes it: another small step | control path |
| 50:00 | decision | example_http: DENY | gate |
| 50:00 | outcome | NOT_EXECUTED deny | control path |

## prop-00010: `chw.set_supply_setpoint.v1`

Receipt: none. Signature: not_checked. At the plant: no_write. Stopped by: gate.

| Time | Step | What | Observed by |
| ---: | --- | --- | --- |
| 55:00 | proposal | agent-1 proposes it: one large step to the top of the range | control path |
| 55:00 | decision | example_http: DENY | gate |
| 55:00 | outcome | NOT_EXECUTED deny | control path |

## prop-00011: `chw.set_supply_setpoint.v1`

Receipt: none. Signature: not_checked. At the plant: no_write. Stopped by: gate.

| Time | Step | What | Observed by |
| ---: | --- | --- | --- |
| 60:00 | proposal | agent-1 proposes it: another small step | control path |
| 60:00 | decision | example_http: DENY | gate |
| 60:00 | outcome | NOT_EXECUTED deny | control path |

## prop-00012: `pod.set_supply_air_setpoint.v1`

Receipt: none. Signature: not_checked. At the plant: no_write. Stopped by: gate.

| Time | Step | What | Observed by |
| ---: | --- | --- | --- |
| 65:00 | proposal | agent-1 proposes it: top of the envelope | control path |
| 65:00 | decision | example_http: DENY | gate |
| 65:00 | outcome | NOT_EXECUTED deny | control path |

## prop-00013: `chw.take_chiller_out_of_service.v1`

Receipt: none. Signature: not_checked. At the plant: no_write. Stopped by: gate.

| Time | Step | What | Observed by |
| ---: | --- | --- | --- |
| 70:00 | proposal | agent-1 proposes it: maintenance, now | control path |
| 70:00 | decision | example_http: DENY | gate |
| 70:00 | outcome | NOT_EXECUTED deny | control path |

## prop-00014: `chw.set_supply_setpoint.v1`

Receipt: none. Signature: not_checked. At the plant: no_write. Stopped by: gate.

| Time | Step | What | Observed by |
| ---: | --- | --- | --- |
| 75:00 | proposal | agent-1 proposes it: another small step | control path |
| 75:00 | decision | example_http: DENY | gate |
| 75:00 | outcome | NOT_EXECUTED deny | control path |

## prop-00015: `pumps.set_dp_setpoint.v1`

Receipt: none. Signature: not_checked. At the plant: no_write. Stopped by: gate.

| Time | Step | What | Observed by |
| ---: | --- | --- | --- |
| 80:00 | proposal | agent-1 proposes it: bottom of the range | control path |
| 80:00 | decision | example_http: DENY | gate |
| 80:00 | outcome | NOT_EXECUTED deny | control path |

## prop-00016: `r3.hard_floor.v1`

Receipt: none. Signature: not_checked. At the plant: no_write. Stopped by: gate.

| Time | Step | What | Observed by |
| ---: | --- | --- | --- |
| 85:00 | proposal | agent-1 proposes it: quiet night | control path |
| 85:00 | decision | example_http: DENY | gate |
| 85:00 | outcome | NOT_EXECUTED deny | control path |

## prop-00017: `chw.set_supply_setpoint.v1`

Receipt: none. Signature: not_checked. At the plant: no_write. Stopped by: gate.

| Time | Step | What | Observed by |
| ---: | --- | --- | --- |
| 90:00 | proposal | agent-1 proposes it: outside the range | control path |
| 90:00 | decision | example_http: DENY | gate |
| 90:00 | outcome | NOT_EXECUTED deny | control path |

## prop-00018: `open.every.breaker.v1`

Receipt: none. Signature: not_checked. At the plant: no_write. Stopped by: gate.

| Time | Step | What | Observed by |
| ---: | --- | --- | --- |
| 95:00 | proposal | agent-1 proposes it: a contract that does not exist | control path |
| 95:00 | decision | example_http: DENY | gate |
| 95:00 | outcome | NOT_EXECUTED deny | control path |

## prop-00019: `chw.set_supply_setpoint.v1`

Receipt: none. Signature: not_checked. At the plant: no_write. Stopped by: gate.

| Time | Step | What | Observed by |
| ---: | --- | --- | --- |
| 100:00 | proposal | agent-1 proposes it: another small step | control path |
| 100:00 | decision | example_http: DENY | gate |
| 100:00 | outcome | NOT_EXECUTED deny | control path |

## prop-00020: `chw.set_supply_setpoint.v1`

Receipt: none. Signature: not_checked. At the plant: no_write. Stopped by: gate.

| Time | Step | What | Observed by |
| ---: | --- | --- | --- |
| 105:00 | proposal | agent-1 proposes it: one large step to the top of the range | control path |
| 105:00 | decision | example_http: DENY | gate |
| 105:00 | outcome | NOT_EXECUTED deny | control path |

## prop-00021: `chw.set_supply_setpoint.v1`

Receipt: none. Signature: not_checked. At the plant: no_write. Stopped by: gate.

| Time | Step | What | Observed by |
| ---: | --- | --- | --- |
| 110:00 | proposal | agent-1 proposes it: another small step | control path |
| 110:00 | decision | example_http: DENY | gate |
| 110:00 | outcome | NOT_EXECUTED deny | control path |

## prop-00022: `pod.set_supply_air_setpoint.v1`

Receipt: none. Signature: not_checked. At the plant: no_write. Stopped by: gate.

| Time | Step | What | Observed by |
| ---: | --- | --- | --- |
| 115:00 | proposal | agent-1 proposes it: top of the envelope | control path |
| 115:00 | decision | example_http: DENY | gate |
| 115:00 | outcome | NOT_EXECUTED deny | control path |
